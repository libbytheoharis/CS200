#include <iostream>
#include <string>
using namespace std;

int main()
{
	int countUp = 1;

	while (countUp < 11)
	{
		cout << countUp << " "; //this will print with spaces
		countUp++;
	}

	cout << endl << endl << "Done!" << endl;
	//spaces make it look a bit better

	return 0;
}