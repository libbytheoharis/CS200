#include <iostream>
#include <string>
using namespace std;

int main()
{
	int secretNumber = 8; 
	int playerGuess; 

	do
	{
		cout << "Please enter your guess: ";
		cin >> playerGuess; 

		if (playerGuess < secretNumber)
		{
			cout << "Too low!!" << endl; 
		}
		else if ( playerGuess > secretNumber )
		{
			cout << "Too high!!" << endl;
		}

	} while ( playerGuess != secretNumber ); 

	cout << "You win!!" << endl;

	return 0;
}