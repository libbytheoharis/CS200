#include <iostream>
#include <string>
using namespace std;

int main()
{
	string homeTown, name;

	cout << "What is your home town? ";
	cin >> homeTown;

	if (homeTown.size() > 6)
	{	
		cout << "That's a long name!" << endl;
	}

	cout << "What is your name? ";
	cin >> name; 

	cout << "Hi there " << name
		<< " from " << homeTown << endl;

	while (true); // this prevents the program from closing
	return 0;
}